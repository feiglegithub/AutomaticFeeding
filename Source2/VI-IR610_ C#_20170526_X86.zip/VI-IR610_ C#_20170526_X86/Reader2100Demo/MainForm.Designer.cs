﻿namespace ReaderDemo
{
    partial class MainForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.txt485address = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.rdbrs485 = new System.Windows.Forms.RadioButton();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.comboBox19 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.listView4 = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.radioButton43 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.groupBox43 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.radioButton26 = new System.Windows.Forms.RadioButton();
            this.radioButton27 = new System.Windows.Forms.RadioButton();
            this.radioButton28 = new System.Windows.Forms.RadioButton();
            this.radioButton44 = new System.Windows.Forms.RadioButton();
            this.radioButton45 = new System.Windows.Forms.RadioButton();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.radioButton24 = new System.Windows.Forms.RadioButton();
            this.radioButton25 = new System.Windows.Forms.RadioButton();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.radioButton23 = new System.Windows.Forms.RadioButton();
            this.radioButton30 = new System.Windows.Forms.RadioButton();
            this.groupBox52 = new System.Windows.Forms.GroupBox();
            this.radioButton40 = new System.Windows.Forms.RadioButton();
            this.radioButton41 = new System.Windows.Forms.RadioButton();
            this.comboBox18 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.groupBox49 = new System.Windows.Forms.GroupBox();
            this.radioButton48 = new System.Windows.Forms.RadioButton();
            this.radioButton47 = new System.Windows.Forms.RadioButton();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.groupBox45 = new System.Windows.Forms.GroupBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.groupBox46 = new System.Windows.Forms.GroupBox();
            this.radioButton35 = new System.Windows.Forms.RadioButton();
            this.radioButton37 = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.radioButton33 = new System.Windows.Forms.RadioButton();
            this.radioButton32 = new System.Windows.Forms.RadioButton();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.groupBox44 = new System.Windows.Forms.GroupBox();
            this.button25 = new System.Windows.Forms.Button();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.groupBox42 = new System.Windows.Forms.GroupBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.label46 = new System.Windows.Forms.Label();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.groupBox48 = new System.Windows.Forms.GroupBox();
            this.radioButton46 = new System.Windows.Forms.RadioButton();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox40 = new System.Windows.Forms.GroupBox();
            this.radioButton31 = new System.Windows.Forms.RadioButton();
            this.radioButton29 = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.comboBox15 = new System.Windows.Forms.ComboBox();
            this.comboBox14 = new System.Windows.Forms.ComboBox();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.radioButton22 = new System.Windows.Forms.RadioButton();
            this.radioButton21 = new System.Windows.Forms.RadioButton();
            this.radioButton20 = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.radioButton18 = new System.Windows.Forms.RadioButton();
            this.radioButton17 = new System.Windows.Forms.RadioButton();
            this.radioButton16 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.ckbReadOnly = new System.Windows.Forms.CheckBox();
            this.button15 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.listView5 = new System.Windows.Forms.ListView();
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader15 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox43.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox52.SuspendLayout();
            this.groupBox49.SuspendLayout();
            this.groupBox45.SuspendLayout();
            this.groupBox46.SuspendLayout();
            this.groupBox44.SuspendLayout();
            this.groupBox42.SuspendLayout();
            this.groupBox48.SuspendLayout();
            this.groupBox40.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(824, 594);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.txt485address);
            this.tabPage5.Controls.Add(this.label17);
            this.tabPage5.Controls.Add(this.rdbrs485);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.button12);
            this.tabPage5.Controls.Add(this.comboBox19);
            this.tabPage5.Controls.Add(this.label45);
            this.tabPage5.Controls.Add(this.label44);
            this.tabPage5.Controls.Add(this.label43);
            this.tabPage5.Controls.Add(this.label42);
            this.tabPage5.Controls.Add(this.label41);
            this.tabPage5.Controls.Add(this.textBox38);
            this.tabPage5.Controls.Add(this.textBox37);
            this.tabPage5.Controls.Add(this.textBox36);
            this.tabPage5.Controls.Add(this.textBox35);
            this.tabPage5.Controls.Add(this.listView4);
            this.tabPage5.Controls.Add(this.button27);
            this.tabPage5.Controls.Add(this.button26);
            this.tabPage5.Controls.Add(this.radioButton43);
            this.tabPage5.Controls.Add(this.radioButton42);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(816, 568);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Connect Reader";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // txt485address
            // 
            this.txt485address.Enabled = false;
            this.txt485address.Location = new System.Drawing.Point(169, 332);
            this.txt485address.Name = "txt485address";
            this.txt485address.Size = new System.Drawing.Size(89, 21);
            this.txt485address.TabIndex = 19;
            this.txt485address.Text = "1";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(76, 336);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 12);
            this.label17.TabIndex = 18;
            this.label17.Text = "RS485 address:";
            // 
            // rdbrs485
            // 
            this.rdbrs485.AutoSize = true;
            this.rdbrs485.Location = new System.Drawing.Point(225, 52);
            this.rdbrs485.Name = "rdbrs485";
            this.rdbrs485.Size = new System.Drawing.Size(53, 16);
            this.rdbrs485.TabIndex = 17;
            this.rdbrs485.TabStop = true;
            this.rdbrs485.Text = "RS485";
            this.rdbrs485.UseVisualStyleBackColor = true;
            this.rdbrs485.CheckedChanged += new System.EventHandler(this.rdbrs485_CheckedChanged);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(493, 299);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(108, 27);
            this.button13.TabIndex = 16;
            this.button13.Text = "Stop Scan";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(352, 299);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(112, 27);
            this.button12.TabIndex = 15;
            this.button12.Text = "Scan Device";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // comboBox19
            // 
            this.comboBox19.FormattingEnabled = true;
            this.comboBox19.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6"});
            this.comboBox19.Location = new System.Drawing.Point(169, 300);
            this.comboBox19.Name = "comboBox19";
            this.comboBox19.Size = new System.Drawing.Size(88, 20);
            this.comboBox19.TabIndex = 14;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(88, 303);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(77, 12);
            this.label45.TabIndex = 13;
            this.label45.Text = "Serial Port:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(83, 255);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 12);
            this.label44.TabIndex = 11;
            this.label44.Text = "Port of Host:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(47, 211);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(119, 12);
            this.label43.TabIndex = 10;
            this.label43.Text = "IP Address of Host:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(71, 164);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(95, 12);
            this.label42.TabIndex = 9;
            this.label42.Text = "Port of Reader:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(35, 121);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(131, 12);
            this.label41.TabIndex = 8;
            this.label41.Text = "IP Address of Reader:";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(171, 252);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(88, 21);
            this.textBox38.TabIndex = 7;
            this.textBox38.Text = "9000";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(170, 207);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(88, 21);
            this.textBox37.TabIndex = 6;
            this.textBox37.Text = "192.168.0.100";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(171, 161);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(88, 21);
            this.textBox36.TabIndex = 5;
            this.textBox36.Text = "8899";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(171, 118);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(88, 21);
            this.textBox35.TabIndex = 4;
            this.textBox35.Text = "192.168.1.212";
            // 
            // listView4
            // 
            this.listView4.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10});
            this.listView4.FullRowSelect = true;
            this.listView4.GridLines = true;
            this.listView4.Location = new System.Drawing.Point(342, 105);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(275, 188);
            this.listView4.TabIndex = 0;
            this.listView4.UseCompatibleStateImageBehavior = false;
            this.listView4.View = System.Windows.Forms.View.Details;
            this.listView4.Click += new System.EventHandler(this.listView4_Click);
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "NO.";
            this.columnHeader8.Width = 40;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "IP Address";
            this.columnHeader9.Width = 150;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Port";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(513, 43);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(88, 35);
            this.button27.TabIndex = 3;
            this.button27.Text = "Disconnect";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(352, 43);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(117, 35);
            this.button26.TabIndex = 2;
            this.button26.Text = "Connect Reader";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // radioButton43
            // 
            this.radioButton43.AutoSize = true;
            this.radioButton43.Location = new System.Drawing.Point(149, 52);
            this.radioButton43.Name = "radioButton43";
            this.radioButton43.Size = new System.Drawing.Size(53, 16);
            this.radioButton43.TabIndex = 1;
            this.radioButton43.TabStop = true;
            this.radioButton43.Text = "RS232";
            this.radioButton43.UseVisualStyleBackColor = true;
            this.radioButton43.CheckedChanged += new System.EventHandler(this.radioButton43_CheckedChanged);
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Checked = true;
            this.radioButton42.Location = new System.Drawing.Point(69, 52);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(59, 16);
            this.radioButton42.TabIndex = 0;
            this.radioButton42.TabStop = true;
            this.radioButton42.Text = "TCP/IP";
            this.radioButton42.UseVisualStyleBackColor = true;
            this.radioButton42.CheckedChanged += new System.EventHandler(this.radioButton42_CheckedChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox16);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.groupBox21);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.button29);
            this.tabPage1.Controls.Add(this.button24);
            this.tabPage1.Controls.Add(this.textBox42);
            this.tabPage1.Controls.Add(this.groupBox43);
            this.tabPage1.Controls.Add(this.textBox41);
            this.tabPage1.Controls.Add(this.groupBox44);
            this.tabPage1.Controls.Add(this.textBox40);
            this.tabPage1.Controls.Add(this.groupBox42);
            this.tabPage1.Controls.Add(this.label49);
            this.tabPage1.Controls.Add(this.label48);
            this.tabPage1.Controls.Add(this.label31);
            this.tabPage1.Controls.Add(this.label47);
            this.tabPage1.Controls.Add(this.textBox28);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(816, 568);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Set Parameters";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(145, 537);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 21);
            this.textBox16.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(109, 541);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 12);
            this.label16.TabIndex = 30;
            this.label16.Text = "MAC:";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(686, 116);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(117, 36);
            this.button11.TabIndex = 29;
            this.button11.Text = "Stop Auto";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.button10);
            this.groupBox21.Controls.Add(this.button9);
            this.groupBox21.Controls.Add(this.textBox15);
            this.groupBox21.Controls.Add(this.label15);
            this.groupBox21.Controls.Add(this.label14);
            this.groupBox21.Controls.Add(this.textBox14);
            this.groupBox21.Controls.Add(this.textBox13);
            this.groupBox21.Controls.Add(this.label13);
            this.groupBox21.Controls.Add(this.checkBox21);
            this.groupBox21.Location = new System.Drawing.Point(267, 411);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(543, 80);
            this.groupBox21.TabIndex = 28;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "ReportFilter";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(419, 43);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 28;
            this.button10.Text = "Get Filter";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(314, 43);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 27;
            this.button9.Text = "Set Filter";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(104, 45);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(188, 21);
            this.textBox15.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(89, 12);
            this.label15.TabIndex = 25;
            this.label15.Text = "Tag Data(HEX):";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(230, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 12);
            this.label14.TabIndex = 24;
            this.label14.Text = "Length of Tag EPC(bit):";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(377, 12);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(51, 21);
            this.textBox14.TabIndex = 23;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(165, 16);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(57, 21);
            this.textBox13.TabIndex = 22;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(155, 12);
            this.label13.TabIndex = 21;
            this.label13.Text = "Address of Tag EPC (bit):";
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(443, 16);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(84, 16);
            this.checkBox21.TabIndex = 20;
            this.checkBox21.Text = "Ctrl Relay";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.button28);
            this.groupBox1.Controls.Add(this.textBox45);
            this.groupBox1.Location = new System.Drawing.Point(270, 497);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 65);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Set or Get time of Reader";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(252, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "Set Time";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(253, 39);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 23);
            this.button28.TabIndex = 23;
            this.button28.Text = "Get Time";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(17, 27);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(215, 21);
            this.textBox45.TabIndex = 21;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(686, 62);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(117, 36);
            this.button29.TabIndex = 20;
            this.button29.Text = "Factory Parameter";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(685, 14);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(117, 36);
            this.button24.TabIndex = 7;
            this.button24.Text = "Update Parameter";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(145, 507);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 21);
            this.textBox42.TabIndex = 19;
            this.textBox42.Text = "textBox42";
            // 
            // groupBox43
            // 
            this.groupBox43.Controls.Add(this.checkBox6);
            this.groupBox43.Controls.Add(this.checkBox5);
            this.groupBox43.Controls.Add(this.textBox12);
            this.groupBox43.Controls.Add(this.textBox11);
            this.groupBox43.Controls.Add(this.textBox10);
            this.groupBox43.Controls.Add(this.label12);
            this.groupBox43.Controls.Add(this.label11);
            this.groupBox43.Controls.Add(this.label10);
            this.groupBox43.Controls.Add(this.groupBox20);
            this.groupBox43.Controls.Add(this.groupBox19);
            this.groupBox43.Controls.Add(this.groupBox18);
            this.groupBox43.Controls.Add(this.groupBox52);
            this.groupBox43.Controls.Add(this.comboBox18);
            this.groupBox43.Controls.Add(this.label38);
            this.groupBox43.Controls.Add(this.textBox44);
            this.groupBox43.Controls.Add(this.groupBox49);
            this.groupBox43.Controls.Add(this.label51);
            this.groupBox43.Controls.Add(this.textBox43);
            this.groupBox43.Controls.Add(this.groupBox45);
            this.groupBox43.Controls.Add(this.groupBox46);
            this.groupBox43.Controls.Add(this.label50);
            this.groupBox43.Location = new System.Drawing.Point(3, 184);
            this.groupBox43.Name = "groupBox43";
            this.groupBox43.Size = new System.Drawing.Size(810, 225);
            this.groupBox43.TabIndex = 6;
            this.groupBox43.TabStop = false;
            this.groupBox43.Text = "Auto Parameters ";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(263, 197);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(90, 16);
            this.checkBox6.TabIndex = 30;
            this.checkBox6.Text = "Check Alarm";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.Visible = false;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(240, 118);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(102, 16);
            this.checkBox5.TabIndex = 29;
            this.checkBox5.Text = "Report Output";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(542, 71);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(87, 21);
            this.textBox12.TabIndex = 28;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(513, 45);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(74, 21);
            this.textBox11.TabIndex = 27;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(513, 18);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(74, 21);
            this.textBox10.TabIndex = 26;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(400, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(137, 12);
            this.label12.TabIndex = 25;
            this.label12.Text = "Diapause of Report(s):";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(413, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(95, 12);
            this.label11.TabIndex = 24;
            this.label11.Text = "Number of Tags:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(407, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 12);
            this.label10.TabIndex = 23;
            this.label10.Text = "Storing Time(s):";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.radioButton26);
            this.groupBox20.Controls.Add(this.radioButton27);
            this.groupBox20.Controls.Add(this.radioButton28);
            this.groupBox20.Controls.Add(this.radioButton44);
            this.groupBox20.Controls.Add(this.radioButton45);
            this.groupBox20.Location = new System.Drawing.Point(233, 16);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(161, 98);
            this.groupBox20.TabIndex = 22;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Condition of Report";
            // 
            // radioButton26
            // 
            this.radioButton26.AutoSize = true;
            this.radioButton26.Checked = true;
            this.radioButton26.Location = new System.Drawing.Point(8, 15);
            this.radioButton26.Name = "radioButton26";
            this.radioButton26.Size = new System.Drawing.Size(83, 16);
            this.radioButton26.TabIndex = 0;
            this.radioButton26.TabStop = true;
            this.radioButton26.Text = "Notify Now";
            this.radioButton26.UseVisualStyleBackColor = true;
            // 
            // radioButton27
            // 
            this.radioButton27.AutoSize = true;
            this.radioButton27.Location = new System.Drawing.Point(8, 54);
            this.radioButton27.Name = "radioButton27";
            this.radioButton27.Size = new System.Drawing.Size(41, 16);
            this.radioButton27.TabIndex = 2;
            this.radioButton27.Text = "Add";
            this.radioButton27.UseVisualStyleBackColor = true;
            // 
            // radioButton28
            // 
            this.radioButton28.AutoSize = true;
            this.radioButton28.Location = new System.Drawing.Point(7, 33);
            this.radioButton28.Name = "radioButton28";
            this.radioButton28.Size = new System.Drawing.Size(101, 16);
            this.radioButton28.TabIndex = 1;
            this.radioButton28.Text = "Timing Notify";
            this.radioButton28.UseVisualStyleBackColor = true;
            // 
            // radioButton44
            // 
            this.radioButton44.AutoSize = true;
            this.radioButton44.Location = new System.Drawing.Point(8, 74);
            this.radioButton44.Name = "radioButton44";
            this.radioButton44.Size = new System.Drawing.Size(59, 16);
            this.radioButton44.TabIndex = 4;
            this.radioButton44.Text = "Change";
            this.radioButton44.UseVisualStyleBackColor = true;
            // 
            // radioButton45
            // 
            this.radioButton45.AutoSize = true;
            this.radioButton45.Location = new System.Drawing.Point(80, 54);
            this.radioButton45.Name = "radioButton45";
            this.radioButton45.Size = new System.Drawing.Size(59, 16);
            this.radioButton45.TabIndex = 3;
            this.radioButton45.Text = "Remove";
            this.radioButton45.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.radioButton24);
            this.groupBox19.Controls.Add(this.radioButton25);
            this.groupBox19.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.groupBox19.Location = new System.Drawing.Point(6, 185);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(251, 38);
            this.groupBox19.TabIndex = 21;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Trigger";
            // 
            // radioButton24
            // 
            this.radioButton24.AutoSize = true;
            this.radioButton24.Location = new System.Drawing.Point(45, 16);
            this.radioButton24.Name = "radioButton24";
            this.radioButton24.Size = new System.Drawing.Size(41, 16);
            this.radioButton24.TabIndex = 1;
            this.radioButton24.TabStop = true;
            this.radioButton24.Text = "Low";
            this.radioButton24.UseVisualStyleBackColor = false;
            // 
            // radioButton25
            // 
            this.radioButton25.AutoSize = true;
            this.radioButton25.Location = new System.Drawing.Point(150, 16);
            this.radioButton25.Name = "radioButton25";
            this.radioButton25.Size = new System.Drawing.Size(47, 16);
            this.radioButton25.TabIndex = 0;
            this.radioButton25.TabStop = true;
            this.radioButton25.Text = "High";
            this.radioButton25.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.radioButton23);
            this.groupBox18.Controls.Add(this.radioButton30);
            this.groupBox18.Location = new System.Drawing.Point(8, 58);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(218, 37);
            this.groupBox18.TabIndex = 20;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Auto Mode";
            // 
            // radioButton23
            // 
            this.radioButton23.AutoSize = true;
            this.radioButton23.Checked = true;
            this.radioButton23.Location = new System.Drawing.Point(21, 16);
            this.radioButton23.Name = "radioButton23";
            this.radioButton23.Size = new System.Drawing.Size(83, 16);
            this.radioButton23.TabIndex = 0;
            this.radioButton23.TabStop = true;
            this.radioButton23.Text = "Continuing";
            this.radioButton23.UseVisualStyleBackColor = true;
            // 
            // radioButton30
            // 
            this.radioButton30.AutoSize = true;
            this.radioButton30.Location = new System.Drawing.Point(119, 16);
            this.radioButton30.Name = "radioButton30";
            this.radioButton30.Size = new System.Drawing.Size(59, 16);
            this.radioButton30.TabIndex = 8;
            this.radioButton30.TabStop = true;
            this.radioButton30.Text = "Trgger";
            this.radioButton30.UseVisualStyleBackColor = true;
            // 
            // groupBox52
            // 
            this.groupBox52.Controls.Add(this.radioButton40);
            this.groupBox52.Controls.Add(this.radioButton41);
            this.groupBox52.Location = new System.Drawing.Point(8, 97);
            this.groupBox52.Name = "groupBox52";
            this.groupBox52.Size = new System.Drawing.Size(218, 38);
            this.groupBox52.TabIndex = 17;
            this.groupBox52.TabStop = false;
            this.groupBox52.Text = "Format of Output";
            // 
            // radioButton40
            // 
            this.radioButton40.AutoSize = true;
            this.radioButton40.Location = new System.Drawing.Point(18, 16);
            this.radioButton40.Name = "radioButton40";
            this.radioButton40.Size = new System.Drawing.Size(59, 16);
            this.radioButton40.TabIndex = 1;
            this.radioButton40.TabStop = true;
            this.radioButton40.Text = "Direct";
            this.radioButton40.UseVisualStyleBackColor = false;
            // 
            // radioButton41
            // 
            this.radioButton41.AutoSize = true;
            this.radioButton41.Location = new System.Drawing.Point(118, 16);
            this.radioButton41.Name = "radioButton41";
            this.radioButton41.Size = new System.Drawing.Size(71, 16);
            this.radioButton41.TabIndex = 0;
            this.radioButton41.TabStop = true;
            this.radioButton41.Text = "Standard";
            this.radioButton41.UseVisualStyleBackColor = false;
            // 
            // comboBox18
            // 
            this.comboBox18.FormattingEnabled = true;
            this.comboBox18.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms"});
            this.comboBox18.Location = new System.Drawing.Point(542, 99);
            this.comboBox18.Name = "comboBox18";
            this.comboBox18.Size = new System.Drawing.Size(87, 20);
            this.comboBox18.TabIndex = 16;
            this.comboBox18.Text = "comboBox18";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(412, 102);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(125, 12);
            this.label38.TabIndex = 15;
            this.label38.Text = "Interval of Reading:";
            this.label38.UseWaitCursor = true;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(700, 44);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 21);
            this.textBox44.TabIndex = 21;
            this.textBox44.Text = "textBox44";
            // 
            // groupBox49
            // 
            this.groupBox49.Controls.Add(this.radioButton48);
            this.groupBox49.Controls.Add(this.radioButton47);
            this.groupBox49.Controls.Add(this.textBox30);
            this.groupBox49.Controls.Add(this.textBox31);
            this.groupBox49.Controls.Add(this.label33);
            this.groupBox49.Controls.Add(this.label34);
            this.groupBox49.Controls.Add(this.textBox33);
            this.groupBox49.Controls.Add(this.label39);
            this.groupBox49.Location = new System.Drawing.Point(370, 123);
            this.groupBox49.Name = "groupBox49";
            this.groupBox49.Size = new System.Drawing.Size(429, 92);
            this.groupBox49.TabIndex = 16;
            this.groupBox49.TabStop = false;
            this.groupBox49.Text = "Wiegand Port Format";
            // 
            // radioButton48
            // 
            this.radioButton48.AutoSize = true;
            this.radioButton48.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.radioButton48.Location = new System.Drawing.Point(225, 66);
            this.radioButton48.Name = "radioButton48";
            this.radioButton48.Size = new System.Drawing.Size(137, 16);
            this.radioButton48.TabIndex = 21;
            this.radioButton48.TabStop = true;
            this.radioButton48.Text = "SN Selected by User";
            this.radioButton48.UseVisualStyleBackColor = true;
            // 
            // radioButton47
            // 
            this.radioButton47.AutoSize = true;
            this.radioButton47.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.radioButton47.Location = new System.Drawing.Point(225, 46);
            this.radioButton47.Name = "radioButton47";
            this.radioButton47.Size = new System.Drawing.Size(101, 16);
            this.radioButton47.TabIndex = 20;
            this.radioButton47.TabStop = true;
            this.radioButton47.Text = "ID of the Tag";
            this.radioButton47.UseVisualStyleBackColor = true;
            // 
            // textBox30
            // 
            this.textBox30.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox30.Location = new System.Drawing.Point(107, 55);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(74, 21);
            this.textBox30.TabIndex = 14;
            this.textBox30.Text = "textBox30";
            // 
            // textBox31
            // 
            this.textBox31.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox31.Location = new System.Drawing.Point(108, 22);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(74, 21);
            this.textBox31.TabIndex = 0;
            this.textBox31.Text = "textBox31";
            // 
            // label33
            // 
            this.label33.AutoEllipsis = true;
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(77, 24);
            this.label33.TabIndex = 13;
            this.label33.Text = "Pulse Width \r\n(*10us):";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(7, 55);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(89, 24);
            this.label34.TabIndex = 13;
            this.label34.Text = "Pulse Interval\r\n(*10us):";
            // 
            // textBox33
            // 
            this.textBox33.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.textBox33.Location = new System.Drawing.Point(320, 21);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(74, 21);
            this.textBox33.TabIndex = 15;
            this.textBox33.Text = "textBox33";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(189, 25);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(125, 12);
            this.label39.TabIndex = 19;
            this.label39.Text = "Start Address of ID:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(630, 48);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(65, 12);
            this.label51.TabIndex = 16;
            this.label51.Text = "Host Port:";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(699, 17);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 21);
            this.textBox43.TabIndex = 20;
            this.textBox43.Text = "textBox43";
            // 
            // groupBox45
            // 
            this.groupBox45.Controls.Add(this.checkBox14);
            this.groupBox45.Location = new System.Drawing.Point(8, 16);
            this.groupBox45.Name = "groupBox45";
            this.groupBox45.Size = new System.Drawing.Size(218, 41);
            this.groupBox45.TabIndex = 6;
            this.groupBox45.TabStop = false;
            this.groupBox45.Text = "Working Antenna";
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(90, 18);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(48, 16);
            this.checkBox14.TabIndex = 7;
            this.checkBox14.Text = "ANT1";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // groupBox46
            // 
            this.groupBox46.Controls.Add(this.radioButton35);
            this.groupBox46.Controls.Add(this.radioButton37);
            this.groupBox46.Controls.Add(this.radioButton34);
            this.groupBox46.Controls.Add(this.radioButton33);
            this.groupBox46.Controls.Add(this.radioButton32);
            this.groupBox46.Location = new System.Drawing.Point(7, 137);
            this.groupBox46.Name = "groupBox46";
            this.groupBox46.Size = new System.Drawing.Size(356, 47);
            this.groupBox46.TabIndex = 6;
            this.groupBox46.TabStop = false;
            this.groupBox46.Text = "Port for Output";
            // 
            // radioButton35
            // 
            this.radioButton35.AutoSize = true;
            this.radioButton35.Checked = true;
            this.radioButton35.Location = new System.Drawing.Point(6, 20);
            this.radioButton35.Name = "radioButton35";
            this.radioButton35.Size = new System.Drawing.Size(53, 16);
            this.radioButton35.TabIndex = 0;
            this.radioButton35.TabStop = true;
            this.radioButton35.Text = "RS232";
            this.radioButton35.UseVisualStyleBackColor = true;
            // 
            // radioButton37
            // 
            this.radioButton37.AutoSize = true;
            this.radioButton37.Location = new System.Drawing.Point(125, 20);
            this.radioButton37.Name = "radioButton37";
            this.radioButton37.Size = new System.Drawing.Size(59, 16);
            this.radioButton37.TabIndex = 2;
            this.radioButton37.Text = "TCP/IP";
            this.radioButton37.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(68, 20);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(53, 16);
            this.radioButton34.TabIndex = 1;
            this.radioButton34.Text = "RS485";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // radioButton33
            // 
            this.radioButton33.AutoSize = true;
            this.radioButton33.Location = new System.Drawing.Point(271, 20);
            this.radioButton33.Name = "radioButton33";
            this.radioButton33.Size = new System.Drawing.Size(77, 16);
            this.radioButton33.TabIndex = 4;
            this.radioButton33.Text = "Wiegand34";
            this.radioButton33.UseVisualStyleBackColor = true;
            // 
            // radioButton32
            // 
            this.radioButton32.AutoSize = true;
            this.radioButton32.Location = new System.Drawing.Point(192, 20);
            this.radioButton32.Name = "radioButton32";
            this.radioButton32.Size = new System.Drawing.Size(77, 16);
            this.radioButton32.TabIndex = 3;
            this.radioButton32.Text = "Wiegand26";
            this.radioButton32.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(593, 21);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(101, 12);
            this.label50.TabIndex = 15;
            this.label50.Text = "Host IP Address:";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(145, 479);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 21);
            this.textBox41.TabIndex = 18;
            this.textBox41.Text = "textBox41";
            // 
            // groupBox44
            // 
            this.groupBox44.Controls.Add(this.button25);
            this.groupBox44.Controls.Add(this.checkBox18);
            this.groupBox44.Location = new System.Drawing.Point(639, 496);
            this.groupBox44.Name = "groupBox44";
            this.groupBox44.Size = new System.Drawing.Size(149, 66);
            this.groupBox44.TabIndex = 6;
            this.groupBox44.TabStop = false;
            this.groupBox44.Text = "Set Relay";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(26, 36);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(99, 23);
            this.button25.TabIndex = 2;
            this.button25.Text = "Set Relay";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(48, 17);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(60, 16);
            this.checkBox18.TabIndex = 0;
            this.checkBox18.Text = "Relay1";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(145, 449);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 21);
            this.textBox40.TabIndex = 17;
            this.textBox40.Text = "textBox40";
            // 
            // groupBox42
            // 
            this.groupBox42.Controls.Add(this.textBox39);
            this.groupBox42.Controls.Add(this.checkBox20);
            this.groupBox42.Controls.Add(this.label46);
            this.groupBox42.Controls.Add(this.textBox34);
            this.groupBox42.Controls.Add(this.checkBox13);
            this.groupBox42.Controls.Add(this.textBox26);
            this.groupBox42.Controls.Add(this.label26);
            this.groupBox42.Controls.Add(this.label40);
            this.groupBox42.Controls.Add(this.label25);
            this.groupBox42.Controls.Add(this.textBox25);
            this.groupBox42.Controls.Add(this.groupBox48);
            this.groupBox42.Controls.Add(this.textBox29);
            this.groupBox42.Controls.Add(this.textBox27);
            this.groupBox42.Controls.Add(this.label32);
            this.groupBox42.Controls.Add(this.groupBox40);
            this.groupBox42.Controls.Add(this.label30);
            this.groupBox42.Controls.Add(this.label29);
            this.groupBox42.Controls.Add(this.label28);
            this.groupBox42.Controls.Add(this.label27);
            this.groupBox42.Controls.Add(this.comboBox15);
            this.groupBox42.Controls.Add(this.comboBox14);
            this.groupBox42.Controls.Add(this.comboBox13);
            this.groupBox42.Location = new System.Drawing.Point(3, 3);
            this.groupBox42.Name = "groupBox42";
            this.groupBox42.Size = new System.Drawing.Size(657, 180);
            this.groupBox42.TabIndex = 6;
            this.groupBox42.TabStop = false;
            this.groupBox42.Text = "Basic Parameters";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(540, 16);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 21);
            this.textBox39.TabIndex = 5;
            this.textBox39.Text = "textBox39";
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(302, 139);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(102, 16);
            this.checkBox20.TabIndex = 0;
            this.checkBox20.Text = "RS485 NetWork";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(474, 19);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(65, 12);
            this.label46.TabIndex = 4;
            this.label46.Text = "Reader ID:";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(209, 148);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(69, 21);
            this.textBox34.TabIndex = 20;
            this.textBox34.Text = "textBox34";
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(302, 113);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(102, 16);
            this.checkBox13.TabIndex = 0;
            this.checkBox13.Text = "Enable Buzzer";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(387, 41);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(78, 21);
            this.textBox26.TabIndex = 1;
            this.textBox26.Text = "textBox26";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(304, 43);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 12);
            this.label26.TabIndex = 3;
            this.label26.Text = "SoftVersion:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(52, 149);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(155, 12);
            this.label40.TabIndex = 1;
            this.label40.Text = "Address of Reader(1-254):";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(303, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 2;
            this.label25.Text = "HardVersion:";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(386, 16);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(78, 21);
            this.textBox25.TabIndex = 0;
            this.textBox25.Text = "textBox25";
            // 
            // groupBox48
            // 
            this.groupBox48.Controls.Add(this.radioButton46);
            this.groupBox48.Location = new System.Drawing.Point(468, 84);
            this.groupBox48.Name = "groupBox48";
            this.groupBox48.Size = new System.Drawing.Size(180, 85);
            this.groupBox48.TabIndex = 7;
            this.groupBox48.TabStop = false;
            this.groupBox48.Text = "Type of tag";
            // 
            // radioButton46
            // 
            this.radioButton46.AutoSize = true;
            this.radioButton46.Checked = true;
            this.radioButton46.Location = new System.Drawing.Point(45, 38);
            this.radioButton46.Name = "radioButton46";
            this.radioButton46.Size = new System.Drawing.Size(89, 16);
            this.radioButton46.TabIndex = 4;
            this.radioButton46.TabStop = true;
            this.radioButton46.Text = "ISO18000-6C";
            this.radioButton46.UseVisualStyleBackColor = true;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(211, 121);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(67, 21);
            this.textBox29.TabIndex = 11;
            this.textBox29.Text = "textBox29";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(211, 93);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(67, 21);
            this.textBox27.TabIndex = 9;
            this.textBox27.Text = "textBox27";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(4, 124);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(203, 12);
            this.label32.TabIndex = 8;
            this.label32.Text = "Max Tags of once Reading(1～100):";
            // 
            // groupBox40
            // 
            this.groupBox40.Controls.Add(this.radioButton31);
            this.groupBox40.Controls.Add(this.radioButton29);
            this.groupBox40.Location = new System.Drawing.Point(302, 65);
            this.groupBox40.Name = "groupBox40";
            this.groupBox40.Size = new System.Drawing.Size(160, 39);
            this.groupBox40.TabIndex = 4;
            this.groupBox40.TabStop = false;
            this.groupBox40.Text = "Work Mode";
            // 
            // radioButton31
            // 
            this.radioButton31.AutoSize = true;
            this.radioButton31.Location = new System.Drawing.Point(82, 15);
            this.radioButton31.Name = "radioButton31";
            this.radioButton31.Size = new System.Drawing.Size(65, 16);
            this.radioButton31.TabIndex = 9;
            this.radioButton31.TabStop = true;
            this.radioButton31.Text = "Command";
            this.radioButton31.UseVisualStyleBackColor = true;
            // 
            // radioButton29
            // 
            this.radioButton29.AutoSize = true;
            this.radioButton29.Checked = true;
            this.radioButton29.Location = new System.Drawing.Point(18, 15);
            this.radioButton29.Name = "radioButton29";
            this.radioButton29.Size = new System.Drawing.Size(47, 16);
            this.radioButton29.TabIndex = 7;
            this.radioButton29.TabStop = true;
            this.radioButton29.Text = "Auto";
            this.radioButton29.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(28, 97);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(179, 12);
            this.label30.TabIndex = 6;
            this.label30.Text = "RF Power Output(18dBm-26dBm):";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(5, 69);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(185, 12);
            this.label29.TabIndex = 5;
            this.label29.Text = "Max.Frequency of Carrier(MHZ):";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(5, 44);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(185, 12);
            this.label28.TabIndex = 4;
            this.label28.Text = "Min.Frequency of Carrier(MHZ):";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(11, 18);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(179, 12);
            this.label27.TabIndex = 3;
            this.label27.Text = "BaudRate of RS232/RS485 Port:";
            // 
            // comboBox15
            // 
            this.comboBox15.FormattingEnabled = true;
            this.comboBox15.Location = new System.Drawing.Point(194, 67);
            this.comboBox15.Name = "comboBox15";
            this.comboBox15.Size = new System.Drawing.Size(86, 20);
            this.comboBox15.TabIndex = 2;
            this.comboBox15.Text = "comboBox15";
            // 
            // comboBox14
            // 
            this.comboBox14.FormattingEnabled = true;
            this.comboBox14.Location = new System.Drawing.Point(195, 41);
            this.comboBox14.Name = "comboBox14";
            this.comboBox14.Size = new System.Drawing.Size(85, 20);
            this.comboBox14.TabIndex = 1;
            this.comboBox14.Text = "comboBox14";
            // 
            // comboBox13
            // 
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Items.AddRange(new object[] {
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.comboBox13.Location = new System.Drawing.Point(195, 16);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(85, 20);
            this.comboBox13.TabIndex = 0;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(43, 511);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(95, 12);
            this.label49.TabIndex = 14;
            this.label49.Text = "Reader Gateway:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(43, 483);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(95, 12);
            this.label48.TabIndex = 13;
            this.label48.Text = "Reader IP mask:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(22, 424);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(113, 12);
            this.label31.TabIndex = 7;
            this.label31.Text = "Reader IP Address:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(61, 452);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(77, 12);
            this.label47.TabIndex = 12;
            this.label47.Text = "Reader Port:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(145, 419);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 21);
            this.textBox28.TabIndex = 10;
            this.textBox28.Text = "textBox28";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Controls.Add(this.groupBox9);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.groupBox7);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(816, 568);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "EPCC1G2_Test";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.button7);
            this.groupBox12.Controls.Add(this.textBox9);
            this.groupBox12.Controls.Add(this.label9);
            this.groupBox12.Controls.Add(this.groupBox17);
            this.groupBox12.Controls.Add(this.groupBox16);
            this.groupBox12.Controls.Add(this.groupBox14);
            this.groupBox12.Controls.Add(this.groupBox13);
            this.groupBox12.Location = new System.Drawing.Point(3, 355);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(508, 206);
            this.groupBox12.TabIndex = 8;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Set protect for reading or writing";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(317, 175);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(109, 23);
            this.button7.TabIndex = 5;
            this.button7.Text = "Set Protect";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(415, 150);
            this.textBox9.MaxLength = 8;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(74, 21);
            this.textBox9.TabIndex = 4;
            this.textBox9.Text = "00000000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(272, 154);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(137, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "Access Password(8HEX):";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.radioButton22);
            this.groupBox17.Controls.Add(this.radioButton21);
            this.groupBox17.Controls.Add(this.radioButton20);
            this.groupBox17.Controls.Add(this.radioButton19);
            this.groupBox17.Location = new System.Drawing.Point(270, 48);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(232, 95);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Lock of EPC TID and User Bank";
            // 
            // radioButton22
            // 
            this.radioButton22.AutoSize = true;
            this.radioButton22.Location = new System.Drawing.Point(9, 73);
            this.radioButton22.Name = "radioButton22";
            this.radioButton22.Size = new System.Drawing.Size(113, 16);
            this.radioButton22.TabIndex = 3;
            this.radioButton22.Text = "Never writeable";
            this.radioButton22.UseVisualStyleBackColor = true;
            // 
            // radioButton21
            // 
            this.radioButton21.AutoSize = true;
            this.radioButton21.Location = new System.Drawing.Point(9, 52);
            this.radioButton21.Name = "radioButton21";
            this.radioButton21.Size = new System.Drawing.Size(215, 16);
            this.radioButton21.TabIndex = 2;
            this.radioButton21.Text = "Writeable from the secured state";
            this.radioButton21.UseVisualStyleBackColor = true;
            // 
            // radioButton20
            // 
            this.radioButton20.AutoSize = true;
            this.radioButton20.Location = new System.Drawing.Point(9, 32);
            this.radioButton20.Name = "radioButton20";
            this.radioButton20.Size = new System.Drawing.Size(149, 16);
            this.radioButton20.TabIndex = 1;
            this.radioButton20.Text = "Permanently writeable";
            this.radioButton20.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Checked = true;
            this.radioButton19.Location = new System.Drawing.Point(9, 14);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(167, 16);
            this.radioButton19.TabIndex = 0;
            this.radioButton19.TabStop = true;
            this.radioButton19.Text = "Writeable from any state";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.comboBox5);
            this.groupBox16.Location = new System.Drawing.Point(282, 12);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(207, 36);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Select a Tag";
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(18, 12);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(175, 20);
            this.comboBox5.TabIndex = 0;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.radioButton18);
            this.groupBox14.Controls.Add(this.radioButton17);
            this.groupBox14.Controls.Add(this.radioButton16);
            this.groupBox14.Controls.Add(this.radioButton15);
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Location = new System.Drawing.Point(3, 49);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(259, 152);
            this.groupBox14.TabIndex = 1;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Lock of Password";
            // 
            // radioButton18
            // 
            this.radioButton18.AutoSize = true;
            this.radioButton18.Location = new System.Drawing.Point(7, 123);
            this.radioButton18.Name = "radioButton18";
            this.radioButton18.Size = new System.Drawing.Size(191, 16);
            this.radioButton18.TabIndex = 4;
            this.radioButton18.Text = "Never readable and writeable";
            this.radioButton18.UseVisualStyleBackColor = true;
            // 
            // radioButton17
            // 
            this.radioButton17.AutoSize = true;
            this.radioButton17.Location = new System.Drawing.Point(7, 94);
            this.radioButton17.Name = "radioButton17";
            this.radioButton17.Size = new System.Drawing.Size(191, 28);
            this.radioButton17.TabIndex = 3;
            this.radioButton17.Text = "Readable and writeable from \r\nthe secured state";
            this.radioButton17.UseVisualStyleBackColor = true;
            // 
            // radioButton16
            // 
            this.radioButton16.AutoSize = true;
            this.radioButton16.Location = new System.Drawing.Point(7, 77);
            this.radioButton16.Name = "radioButton16";
            this.radioButton16.Size = new System.Drawing.Size(227, 16);
            this.radioButton16.TabIndex = 2;
            this.radioButton16.Text = "Permanently readable and writeable";
            this.radioButton16.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Checked = true;
            this.radioButton15.Location = new System.Drawing.Point(7, 58);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(245, 16);
            this.radioButton15.TabIndex = 2;
            this.radioButton15.TabStop = true;
            this.radioButton15.Text = "Readable and writeable from any state";
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.radioButton14);
            this.groupBox15.Controls.Add(this.radioButton13);
            this.groupBox15.Location = new System.Drawing.Point(5, 13);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(247, 39);
            this.groupBox15.TabIndex = 2;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Password";
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(119, 17);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(113, 16);
            this.radioButton14.TabIndex = 2;
            this.radioButton14.Text = "Access Password";
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Checked = true;
            this.radioButton13.Location = new System.Drawing.Point(10, 17);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(101, 16);
            this.radioButton13.TabIndex = 2;
            this.radioButton13.TabStop = true;
            this.radioButton13.Text = "Kill Password";
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.radioButton12);
            this.groupBox13.Controls.Add(this.radioButton11);
            this.groupBox13.Controls.Add(this.radioButton10);
            this.groupBox13.Controls.Add(this.radioButton9);
            this.groupBox13.Location = new System.Drawing.Point(3, 13);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(237, 35);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Select Memory Bank";
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(169, 13);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(47, 16);
            this.radioButton12.TabIndex = 5;
            this.radioButton12.TabStop = true;
            this.radioButton12.Text = "User";
            this.radioButton12.UseVisualStyleBackColor = true;
            this.radioButton12.CheckedChanged += new System.EventHandler(this.radioButton12_CheckedChanged);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(124, 13);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(41, 16);
            this.radioButton11.TabIndex = 4;
            this.radioButton11.TabStop = true;
            this.radioButton11.Text = "TID";
            this.radioButton11.UseVisualStyleBackColor = true;
            this.radioButton11.CheckedChanged += new System.EventHandler(this.radioButton11_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Checked = true;
            this.radioButton10.Location = new System.Drawing.Point(79, 13);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(41, 16);
            this.radioButton10.TabIndex = 3;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "EPC";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.CheckedChanged += new System.EventHandler(this.radioButton10_CheckedChanged);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(6, 13);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(71, 16);
            this.radioButton9.TabIndex = 2;
            this.radioButton9.Text = "Password";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.button4);
            this.groupBox9.Controls.Add(this.textBox4);
            this.groupBox9.Controls.Add(this.label4);
            this.groupBox9.Controls.Add(this.groupBox10);
            this.groupBox9.Location = new System.Drawing.Point(6, 258);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(237, 96);
            this.groupBox9.TabIndex = 7;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Kill  Tag";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(175, 56);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(49, 36);
            this.button4.TabIndex = 8;
            this.button4.Text = "Kill \r\nTag";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(107, 57);
            this.textBox4.MaxLength = 8;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 21);
            this.textBox4.TabIndex = 8;
            this.textBox4.Text = "00000000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 24);
            this.label4.TabIndex = 8;
            this.label4.Text = "Killer PassWord\r\n(8HEX):";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.comboBox4);
            this.groupBox10.Location = new System.Drawing.Point(6, 15);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(213, 39);
            this.groupBox10.TabIndex = 8;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Select a Tag";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(21, 13);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(168, 20);
            this.comboBox4.TabIndex = 8;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.button3);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.groupBox6);
            this.groupBox4.Location = new System.Drawing.Point(6, 86);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(237, 170);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "List Selected Tag";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.Location = new System.Drawing.Point(8, 142);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(202, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "List Tag ID";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 117);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(207, 21);
            this.textBox3.TabIndex = 8;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(164, 80);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(55, 21);
            this.textBox2.TabIndex = 8;
            this.textBox2.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tag Data(HEX):";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(164, 57);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(55, 21);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Length of Tag Data(bit):";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 12);
            this.label1.TabIndex = 7;
            this.label1.Text = "Address of Tag Data(bit):";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton4);
            this.groupBox6.Controls.Add(this.radioButton3);
            this.groupBox6.Controls.Add(this.radioButton2);
            this.groupBox6.Controls.Add(this.radioButton1);
            this.groupBox6.Location = new System.Drawing.Point(6, 13);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(213, 42);
            this.groupBox6.TabIndex = 2;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Select Memory Bank";
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(163, 18);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(47, 16);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "User";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Enabled = false;
            this.radioButton3.Location = new System.Drawing.Point(117, 18);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(41, 16);
            this.radioButton3.TabIndex = 5;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "TID";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(76, 18);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(41, 16);
            this.radioButton2.TabIndex = 4;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "EPC";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Enabled = false;
            this.radioButton1.Location = new System.Drawing.Point(3, 17);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 16);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.Text = "PassWord";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.textBox8);
            this.groupBox5.Controls.Add(this.textBox7);
            this.groupBox5.Controls.Add(this.textBox6);
            this.groupBox5.Controls.Add(this.textBox5);
            this.groupBox5.Controls.Add(this.groupBox11);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.listBox1);
            this.groupBox5.Controls.Add(this.groupBox8);
            this.groupBox5.Location = new System.Drawing.Point(249, 190);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(534, 160);
            this.groupBox5.TabIndex = 2;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Read and Write Data Block";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(427, 125);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 23);
            this.button6.TabIndex = 12;
            this.button6.Text = "Write";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(363, 125);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(56, 23);
            this.button5.TabIndex = 11;
            this.button5.Text = "Read";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(120, 129);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(234, 21);
            this.textBox8.TabIndex = 10;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(171, 103);
            this.textBox7.MaxLength = 8;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(58, 21);
            this.textBox7.TabIndex = 9;
            this.textBox7.Text = "00000000";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(171, 81);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(58, 21);
            this.textBox6.TabIndex = 8;
            this.textBox6.Text = "1";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(171, 57);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(58, 21);
            this.textBox5.TabIndex = 7;
            this.textBox5.Text = "0";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.radioButton8);
            this.groupBox11.Controls.Add(this.radioButton7);
            this.groupBox11.Controls.Add(this.radioButton6);
            this.groupBox11.Controls.Add(this.radioButton5);
            this.groupBox11.Location = new System.Drawing.Point(225, 10);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(303, 42);
            this.groupBox11.TabIndex = 6;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Select Memory Bank";
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(229, 17);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(47, 16);
            this.radioButton8.TabIndex = 3;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "User";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(175, 17);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(41, 16);
            this.radioButton7.TabIndex = 2;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "TID";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Checked = true;
            this.radioButton6.Location = new System.Drawing.Point(121, 17);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(41, 16);
            this.radioButton6.TabIndex = 1;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "EPC";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(37, 17);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(71, 16);
            this.radioButton5.TabIndex = 0;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Password";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 130);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = "Written Data(HEX):";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 109);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "Access Password(8HEX):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "Length of Tag Data(WORD):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 12);
            this.label5.TabIndex = 2;
            this.label5.Text = "Address of Tag Data(WORD):";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(235, 56);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(252, 64);
            this.listBox1.TabIndex = 1;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.comboBox3);
            this.groupBox8.Location = new System.Drawing.Point(5, 13);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(214, 41);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Select a Tag";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(19, 15);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(175, 20);
            this.comboBox3.TabIndex = 2;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.listView1);
            this.groupBox7.Location = new System.Drawing.Point(249, 3);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(534, 184);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "List EPC of Tags";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader11,
            this.columnHeader12});
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(0, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(522, 164);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "NO.";
            this.columnHeader1.Width = 35;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "ID.";
            this.columnHeader2.Width = 211;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Length";
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Success";
            this.columnHeader11.Width = 70;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Times";
            this.columnHeader12.Width = 80;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Location = new System.Drawing.Point(6, 44);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(237, 42);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "ReaderInterval";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "10ms",
            "20ms",
            "30ms",
            "50ms",
            "100ms",
            "200ms",
            "500ms"});
            this.comboBox2.Location = new System.Drawing.Point(59, 15);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 20);
            this.comboBox2.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(237, 40);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Select Antenna for Test";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(82, 18);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(48, 16);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "ANT1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.ckbReadOnly);
            this.tabPage6.Controls.Add(this.button15);
            this.tabPage6.Controls.Add(this.button14);
            this.tabPage6.Controls.Add(this.listView5);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(816, 568);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Auto Output";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // ckbReadOnly
            // 
            this.ckbReadOnly.AutoSize = true;
            this.ckbReadOnly.Location = new System.Drawing.Point(122, 519);
            this.ckbReadOnly.Name = "ckbReadOnly";
            this.ckbReadOnly.Size = new System.Drawing.Size(108, 16);
            this.ckbReadOnly.TabIndex = 3;
            this.ckbReadOnly.Text = "同标签只读一次";
            this.ckbReadOnly.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(423, 506);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(138, 40);
            this.button15.TabIndex = 2;
            this.button15.Text = "Stop";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(236, 506);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(138, 40);
            this.button14.TabIndex = 1;
            this.button14.Text = "Start";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // listView5
            // 
            this.listView5.BackColor = System.Drawing.Color.White;
            this.listView5.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15});
            this.listView5.GridLines = true;
            this.listView5.Location = new System.Drawing.Point(10, 13);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(789, 481);
            this.listView5.TabIndex = 0;
            this.listView5.UseCompatibleStateImageBehavior = false;
            this.listView5.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "NO.";
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Disc";
            this.columnHeader5.Width = 140;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Last";
            this.columnHeader6.Width = 140;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Count";
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Ant";
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Type";
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "Tag";
            this.columnHeader15.Width = 240;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(824, 594);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "VI-IR610_20170526";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox43.ResumeLayout(false);
            this.groupBox43.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox52.ResumeLayout(false);
            this.groupBox52.PerformLayout();
            this.groupBox49.ResumeLayout(false);
            this.groupBox49.PerformLayout();
            this.groupBox45.ResumeLayout(false);
            this.groupBox45.PerformLayout();
            this.groupBox46.ResumeLayout(false);
            this.groupBox46.PerformLayout();
            this.groupBox44.ResumeLayout(false);
            this.groupBox44.PerformLayout();
            this.groupBox42.ResumeLayout(false);
            this.groupBox42.PerformLayout();
            this.groupBox48.ResumeLayout(false);
            this.groupBox48.PerformLayout();
            this.groupBox40.ResumeLayout(false);
            this.groupBox40.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RadioButton radioButton18;
        private System.Windows.Forms.RadioButton radioButton17;
        private System.Windows.Forms.RadioButton radioButton16;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RadioButton radioButton22;
        private System.Windows.Forms.RadioButton radioButton21;
        private System.Windows.Forms.RadioButton radioButton20;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.GroupBox groupBox46;
        private System.Windows.Forms.GroupBox groupBox44;
        private System.Windows.Forms.GroupBox groupBox45;
        private System.Windows.Forms.GroupBox groupBox43;
        private System.Windows.Forms.GroupBox groupBox42;
        private System.Windows.Forms.GroupBox groupBox40;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.RadioButton radioButton31;
        private System.Windows.Forms.RadioButton radioButton30;
        private System.Windows.Forms.RadioButton radioButton29;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox comboBox15;
        private System.Windows.Forms.ComboBox comboBox14;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.GroupBox groupBox52;
        private System.Windows.Forms.RadioButton radioButton40;
        private System.Windows.Forms.RadioButton radioButton41;
        private System.Windows.Forms.GroupBox groupBox49;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox48;
        private System.Windows.Forms.RadioButton radioButton37;
        private System.Windows.Forms.RadioButton radioButton35;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton radioButton33;
        private System.Windows.Forms.RadioButton radioButton32;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.RadioButton radioButton43;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.ListView listView4;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox comboBox19;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.ComboBox comboBox18;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ListView listView5;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RadioButton radioButton23;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RadioButton radioButton24;
        private System.Windows.Forms.RadioButton radioButton25;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.RadioButton radioButton26;
        private System.Windows.Forms.RadioButton radioButton27;
        private System.Windows.Forms.RadioButton radioButton28;
        private System.Windows.Forms.RadioButton radioButton44;
        private System.Windows.Forms.RadioButton radioButton45;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RadioButton radioButton46;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.RadioButton radioButton48;
        private System.Windows.Forms.RadioButton radioButton47;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label16;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.CheckBox ckbReadOnly;
        private System.Windows.Forms.RadioButton rdbrs485;
        private System.Windows.Forms.TextBox txt485address;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton radioButton4;

    }
}

